import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from copy import deepcopy

from bs4 import BeautifulSoup

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.style import WD_STYLE_TYPE
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn


RESPONSE = {
    'address_to': '''To
Mr. Rakibul Ali
EMP ID: 1234...
Vill- Gahi Gaon, Sootea, Biswanath Assam
Guwahati, Assam - 784175.''',

    'generation_date': "14th May'2026",

    'employee_name': 'Rakibul Ali',

    'subject': "Show Cause Notice - Misappropriation of Company's/Customer's Money - Misconduct.",

    'Ref': "Your Offer/DOJ letter dated 14th Oct'2020.",

    'actual_content': '''You have been serving the Company as Debt Recovery Officer at our Guwahati Branch since 14th Oct'2020.

During a regular check, it was brought to our attention regarding the customer Mr. Bitupan Das bearing loan agreement number AS3072TW0137986. You have collected an amount of Rs.38,000/- in the month of Jan'2026 and instead of depositing the collected amount into company's account, you have deposited the EMIs to the sum of Rs.15,798/- from Jan'2026 to Mar'2026 as detailed in Annexure and still retaining the remaining amount of Rs.22,202/- with yourself which implies your malafide intention to deceive the company by misappropriating the collection amount for personal gains.''',

'table_annexure': '''
<table border="1" cellspacing="0" cellpadding="5">
    <thead>
        <tr>
            <th>EMPLOYEE TO EMPLOYEE TRANSFER</th>
            <th>Date</th>
            <th>Reference</th>
            <th>Amount</th>
            <th>Employee Name</th>
            <th>Designation</th>
            <th>EMPLOYEE ID (Masked)</th>
            <th>Mode</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>EMPLOYEE TO EMPLOYEE TRANSFER</td>
            <td>02/02/2026</td>
            <td>REF001</td>
            <td>8,300</td>
            <td>Solairaja M</td>
            <td>Sales Collection Executive</td>
            <td>1234...</td>
            <td>UPI</td>
        </tr>
        <tr>
            <td>EMPLOYEE TO EMPLOYEE TRANSFER</td>
            <td>04/02/2026</td>
            <td>REF002</td>
            <td>6,400</td>
            <td>Solairaja M</td>
            <td>Sales Collection Executive</td>
            <td>1234...</td>
            <td>UPI</td>
        </tr>
        <tr>
            <td>EMPLOYEE TO EMPLOYEE TRANSFER</td>
            <td>07/02/2026</td>
            <td>REF003</td>
            <td>5,200</td>
            <td>Solairaja M</td>
            <td>Sales Collection Executive</td>
            <td>1234...</td>
            <td>UPI</td>
        </tr>
        <tr>
            <td>EMPLOYEE TO EMPLOYEE TRANSFER</td>
            <td>10/02/2026</td>
            <td>REF004</td>
            <td>4,100</td>
            <td>Solairaja M</td>
            <td>Sales Collection Executive</td>
            <td>1234...</td>
            <td>UPI</td>
        </tr>
        <tr>
            <td>EMPLOYEE TO EMPLOYEE TRANSFER</td>
            <td>15/02/2026</td>
            <td>REF005</td>
            <td>6,000</td>
            <td>Solairaja M</td>
            <td>Sales Collection Executive</td>
            <td>1234...</td>
            <td>UPI</td>
        </tr>
        <tr>
            <td>EMPLOYEE TO EMPLOYEE TRANSFER</td>
            <td>20/02/2026</td>
            <td>REF006</td>
            <td>3,500</td>
            <td>Solairaja M</td>
            <td>Sales Collection Executive</td>
            <td>1234...</td>
            <td>UPI</td>
        </tr>
        <tr>
            <td>EMPLOYEE TO EMPLOYEE TRANSFER</td>
            <td>25/02/2026</td>
            <td>REF007</td>
            <td>4,500</td>
            <td>Solairaja M</td>
            <td>Sales Collection Executive</td>
            <td>1234...</td>
            <td>UPI</td>
        </tr>
        <tr>
            <td>EMPLOYEE TO EMPLOYEE TRANSFER</td>
            <td>01/03/2026</td>
            <td>REF008</td>
            <td>3,798</td>
            <td>Solairaja M</td>
            <td>Sales Collection Executive</td>
            <td>1234...</td>
            <td>UPI</td>
        </tr>
        <tr>
            <td colspan="3"><strong>Total</strong></td>
            <td><strong>41,798</strong></td>
            <td colspan="4"></td>
        </tr>
    </tbody>
</table>
<table border="1" cellspacing="0" cellpadding="5">
    <thead>
        <tr>
            <th>Claim ID</th>
            <th>Claim Date</th>
            <th>Employee Name</th>
            <th>Expense Category</th>
            <th>Description</th>
            <th>Location</th>
            <th>Amount</th>
            <th>Status</th>
            <th>Approved By</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>CLM001</td>
            <td>03/02/2026</td>
            <td>Arun Kumar</td>
            <td>Local Conveyance</td>
            <td>Customer visit</td>
            <td>Chennai</td>
            <td>850</td>
            <td>Approved</td>
            <td>Manager</td>
        </tr>
        <tr>
            <td>CLM002</td>
            <td>05/02/2026</td>
            <td>Arun Kumar</td>
            <td>Food</td>
            <td>Client meeting</td>
            <td>Chennai</td>
            <td>620</td>
            <td>Approved</td>
            <td>Manager</td>
        </tr>
        <tr>
            <td>CLM003</td>
            <td>08/02/2026</td>
            <td>Priya S</td>
            <td>Travel</td>
            <td>Branch visit</td>
            <td>Madurai</td>
            <td>2,450</td>
            <td>Approved</td>
            <td>Regional Manager</td>
        </tr>
        <tr>
            <td>CLM004</td>
            <td>11/02/2026</td>
            <td>Priya S</td>
            <td>Accommodation</td>
            <td>Hotel stay</td>
            <td>Madurai</td>
            <td>3,200</td>
            <td>Pending</td>
            <td>-</td>
        </tr>
        <tr>
            <td>CLM005</td>
            <td>14/02/2026</td>
            <td>Vignesh R</td>
            <td>Local Conveyance</td>
            <td>Collection visits</td>
            <td>Coimbatore</td>
            <td>1,150</td>
            <td>Approved</td>
            <td>Manager</td>
        </tr>
        <tr>
            <td>CLM006</td>
            <td>18/02/2026</td>
            <td>Vignesh R</td>
            <td>Fuel</td>
            <td>Official travel</td>
            <td>Coimbatore</td>
            <td>1,850</td>
            <td>Approved</td>
            <td>Manager</td>
        </tr>
        <tr>
            <td>CLM007</td>
            <td>21/02/2026</td>
            <td>Meena P</td>
            <td>Travel</td>
            <td>Customer meeting</td>
            <td>Salem</td>
            <td>2,100</td>
            <td>Rejected</td>
            <td>Regional Manager</td>
        </tr>
        <tr>
            <td>CLM008</td>
            <td>24/02/2026</td>
            <td>Meena P</td>
            <td>Food</td>
            <td>Business meeting</td>
            <td>Salem</td>
            <td>780</td>
            <td>Approved</td>
            <td>Manager</td>
        </tr>
        <tr>
            <td>CLM009</td>
            <td>27/02/2026</td>
            <td>Ramesh K</td>
            <td>Communication</td>
            <td>Official calls</td>
            <td>Chennai</td>
            <td>450</td>
            <td>Approved</td>
            <td>Manager</td>
        </tr>
        <tr>
            <td>CLM010</td>
            <td>02/03/2026</td>
            <td>Ramesh K</td>
            <td>Local Conveyance</td>
            <td>Branch visit</td>
            <td>Kanchipuram</td>
            <td>1,320</td>
            <td>Pending</td>
            <td>-</td>
        </tr>
        <tr>
            <td>CLM011</td>
            <td>05/03/2026</td>
            <td>Deepak M</td>
            <td>Fuel</td>
            <td>Field collection</td>
            <td>Vellore</td>
            <td>1,670</td>
            <td>Approved</td>
            <td>Manager</td>
        </tr>
        <tr>
            <td>CLM012</td>
            <td>08/03/2026</td>
            <td>Deepak M</td>
            <td>Travel</td>
            <td>Dealer meeting</td>
            <td>Vellore</td>
            <td>2,850</td>
            <td>Approved</td>
            <td>Regional Manager</td>
        </tr>
        <tr>
            <td colspan="6"><strong>Total Approved / Submitted Amount</strong></td>
            <td><strong>19,290</strong></td>
            <td colspan="2"></td>
        </tr>
    </tbody>
</table>

<table border="1" cellspacing="0" cellpadding="5">
    <thead>
        <tr>
            <th>S.No</th>
            <th>Date</th>
            <th>Transaction ID</th>
            <th>Employee Name</th>
            <th>Employee ID</th>
            <th>Department</th>
            <th>Transaction Type</th>
            <th>Mode</th>
            <th>Amount</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <tr><td>1</td><td>01/03/2026</td><td>TXN001</td><td>Arun Kumar</td><td>EMP1...</td><td>Sales</td><td>Transfer</td><td>UPI</td><td>2,500</td><td>Completed</td></tr>
        <tr><td>2</td><td>02/03/2026</td><td>TXN002</td><td>Priya S</td><td>EMP2...</td><td>Operations</td><td>Reimbursement</td><td>NEFT</td><td>4,800</td><td>Completed</td></tr>
        <tr><td>3</td><td>03/03/2026</td><td>TXN003</td><td>Vignesh R</td><td>EMP3...</td><td>Collections</td><td>Transfer</td><td>UPI</td><td>6,200</td><td>Completed</td></tr>
        <tr><td>4</td><td>04/03/2026</td><td>TXN004</td><td>Meena P</td><td>EMP4...</td><td>Sales</td><td>Advance</td><td>IMPS</td><td>3,500</td><td>Pending</td></tr>
        <tr><td>5</td><td>05/03/2026</td><td>TXN005</td><td>Ramesh K</td><td>EMP5...</td><td>Finance</td><td>Reimbursement</td><td>NEFT</td><td>7,850</td><td>Completed</td></tr>
        <tr><td>6</td><td>06/03/2026</td><td>TXN006</td><td>Deepak M</td><td>EMP6...</td><td>Collections</td><td>Transfer</td><td>UPI</td><td>4,250</td><td>Completed</td></tr>
        <tr><td>7</td><td>07/03/2026</td><td>TXN007</td><td>Arun Kumar</td><td>EMP1...</td><td>Sales</td><td>Advance</td><td>UPI</td><td>5,600</td><td>Approved</td></tr>
        <tr><td>8</td><td>08/03/2026</td><td>TXN008</td><td>Priya S</td><td>EMP2...</td><td>Operations</td><td>Transfer</td><td>UPI</td><td>3,100</td><td>Completed</td></tr>
        <tr><td>9</td><td>09/03/2026</td><td>TXN009</td><td>Vignesh R</td><td>EMP3...</td><td>Collections</td><td>Reimbursement</td><td>NEFT</td><td>8,400</td><td>Completed</td></tr>
        <tr><td>10</td><td>10/03/2026</td><td>TXN010</td><td>Meena P</td><td>EMP4...</td><td>Sales</td><td>Transfer</td><td>UPI</td><td>2,750</td><td>Completed</td></tr>
        <tr><td>11</td><td>11/03/2026</td><td>TXN011</td><td>Ramesh K</td><td>EMP5...</td><td>Finance</td><td>Advance</td><td>IMPS</td><td>4,600</td><td>Approved</td></tr>
        <tr><td>12</td><td>12/03/2026</td><td>TXN012</td><td>Deepak M</td><td>EMP6...</td><td>Collections</td><td>Transfer</td><td>UPI</td><td>5,250</td><td>Completed</td></tr>
        <tr><td>13</td><td>13/03/2026</td><td>Arun Kumar</td><td>EMP1...</td><td>Sales</td><td>Reimbursement</td><td>NEFT</td><td>6,750</td><td>Completed</td></tr>
        <tr><td>14</td><td>14/03/2026</td><td>TXN014</td><td>Priya S</td><td>EMP2...</td><td>Operations</td><td>Transfer</td><td>UPI</td><td>3,950</td><td>Completed</td></tr>
        <tr><td>15</td><td>15/03/2026</td><td>TXN015</td><td>Vignesh R</td><td>EMP3...</td><td>Collections</td><td>Advance</td><td>IMPS</td><td>7,200</td><td>Pending</td></tr>
        <tr><td>16</td><td>16/03/2026</td><td>TXN016</td><td>Meena P</td><td>EMP4...</td><td>Sales</td><td>Transfer</td><td>UPI</td><td>4,300</td><td>Completed</td></tr>
        <tr><td>17</td><td>17/03/2026</td><td>TXN017</td><td>Ramesh K</td><td>EMP5...</td><td>Finance</td><td>Reimbursement</td><td>NEFT</td><td>5,900</td><td>Completed</td></tr>
        <tr><td>18</td><td>18/03/2026</td><td>TXN018</td><td>Deepak M</td><td>EMP6...</td><td>Collections</td><td>Transfer</td><td>UPI</td><td>6,450</td><td>Completed</td></tr>
        <tr><td>19</td><td>19/03/2026</td><td>TXN019</td><td>Arun Kumar</td><td>EMP1...</td><td>Sales</td><td>Advance</td><td>UPI</td><td>3,800</td><td>Approved</td></tr>
        <tr><td>20</td><td>20/03/2026</td><td>TXN020</td><td>Priya S</td><td>EMP2...</td><td>Operations</td><td>Transfer</td><td>UPI</td><td>8,100</td><td>Completed</td></tr>
        <tr><td>1</td><td>01/03/2026</td><td>TXN001</td><td>Arun Kumar</td><td>EMP1...</td><td>Sales</td><td>Transfer</td><td>UPI</td><td>2,500</td><td>Completed</td></tr>
        <tr><td>2</td><td>02/03/2026</td><td>TXN002</td><td>Priya S</td><td>EMP2...</td><td>Operations</td><td>Reimbursement</td><td>NEFT</td><td>4,800</td><td>Completed</td></tr>
        <tr><td>3</td><td>03/03/2026</td><td>TXN003</td><td>Vignesh R</td><td>EMP3...</td><td>Collections</td><td>Transfer</td><td>UPI</td><td>6,200</td><td>Completed</td></tr>
        <tr><td>4</td><td>04/03/2026</td><td>TXN004</td><td>Meena P</td><td>EMP4...</td><td>Sales</td><td>Advance</td><td>IMPS</td><td>3,500</td><td>Pending</td></tr>
        <tr><td>5</td><td>05/03/2026</td><td>TXN005</td><td>Ramesh K</td><td>EMP5...</td><td>Finance</td><td>Reimbursement</td><td>NEFT</td><td>7,850</td><td>Completed</td></tr>
        <tr><td>6</td><td>06/03/2026</td><td>TXN006</td><td>Deepak M</td><td>EMP6...</td><td>Collections</td><td>Transfer</td><td>UPI</td><td>4,250</td><td>Completed</td></tr>
        <tr><td>7</td><td>07/03/2026</td><td>TXN007</td><td>Arun Kumar</td><td>EMP1...</td><td>Sales</td><td>Advance</td><td>UPI</td><td>5,600</td><td>Approved</td></tr>
        <tr><td>8</td><td>08/03/2026</td><td>TXN008</td><td>Priya S</td><td>EMP2...</td><td>Operations</td><td>Transfer</td><td>UPI</td><td>3,100</td><td>Completed</td></tr>
        <tr><td>9</td><td>09/03/2026</td><td>TXN009</td><td>Vignesh R</td><td>EMP3...</td><td>Collections</td><td>Reimbursement</td><td>NEFT</td><td>8,400</td><td>Completed</td></tr>
        <tr><td>10</td><td>10/03/2026</td><td>TXN010</td><td>Meena P</td><td>EMP4...</td><td>Sales</td><td>Transfer</td><td>UPI</td><td>2,750</td><td>Completed</td></tr>
        <tr><td>11</td><td>11/03/2026</td><td>TXN011</td><td>Ramesh K</td><td>EMP5...</td><td>Finance</td><td>Advance</td><td>IMPS</td><td>4,600</td><td>Approved</td></tr>
        <tr><td>12</td><td>12/03/2026</td><td>TXN012</td><td>Deepak M</td><td>EMP6...</td><td>Collections</td><td>Transfer</td><td>UPI</td><td>5,250</td><td>Completed</td></tr>
        <tr><td>13</td><td>13/03/2026</td><td>Arun Kumar</td><td>EMP1...</td><td>Sales</td><td>Reimbursement</td><td>NEFT</td><td>6,750</td><td>Completed</td></tr>
        <tr><td>14</td><td>14/03/2026</td><td>TXN014</td><td>Priya S</td><td>EMP2...</td><td>Operations</td><td>Transfer</td><td>UPI</td><td>3,950</td><td>Completed</td></tr>
        <tr><td>15</td><td>15/03/2026</td><td>TXN015</td><td>Vignesh R</td><td>EMP3...</td><td>Collections</td><td>Advance</td><td>IMPS</td><td>7,200</td><td>Pending</td></tr>
        <tr><td>16</td><td>16/03/2026</td><td>TXN016</td><td>Meena P</td><td>EMP4...</td><td>Sales</td><td>Transfer</td><td>UPI</td><td>4,300</td><td>Completed</td></tr>
        <tr><td>17</td><td>17/03/2026</td><td>TXN017</td><td>Ramesh K</td><td>EMP5...</td><td>Finance</td><td>Reimbursement</td><td>NEFT</td><td>5,900</td><td>Completed</td></tr>
        <tr><td>18</td><td>18/03/2026</td><td>TXN018</td><td>Deepak M</td><td>EMP6...</td><td>Collections</td><td>Transfer</td><td>UPI</td><td>6,450</td><td>Completed</td></tr>
        <tr><td>19</td><td>19/03/2026</td><td>TXN019</td><td>Arun Kumar</td><td>EMP1...</td><td>Sales</td><td>Advance</td><td>UPI</td><td>3,800</td><td>Approved</td></tr>
        <tr><td>20</td><td>20/03/2026</td><td>TXN020</td><td>Priya S</td><td>EMP2...</td><td>Operations</td><td>Transfer</td><td>UPI</td><td>8,100</td><td>Completed</td></tr>
        <tr><td>1</td><td>01/03/2026</td><td>TXN001</td><td>Arun Kumar</td><td>EMP1...</td><td>Sales</td><td>Transfer</td><td>UPI</td><td>2,500</td><td>Completed</td></tr>
        <tr><td>2</td><td>02/03/2026</td><td>TXN002</td><td>Priya S</td><td>EMP2...</td><td>Operations</td><td>Reimbursement</td><td>NEFT</td><td>4,800</td><td>Completed</td></tr>
        <tr><td>3</td><td>03/03/2026</td><td>TXN003</td><td>Vignesh R</td><td>EMP3...</td><td>Collections</td><td>Transfer</td><td>UPI</td><td>6,200</td><td>Completed</td></tr>
        <tr><td>4</td><td>04/03/2026</td><td>TXN004</td><td>Meena P</td><td>EMP4...</td><td>Sales</td><td>Advance</td><td>IMPS</td><td>3,500</td><td>Pending</td></tr>
        <tr><td>5</td><td>05/03/2026</td><td>TXN005</td><td>Ramesh K</td><td>EMP5...</td><td>Finance</td><td>Reimbursement</td><td>NEFT</td><td>7,850</td><td>Completed</td></tr>
        <tr><td>6</td><td>06/03/2026</td><td>TXN006</td><td>Deepak M</td><td>EMP6...</td><td>Collections</td><td>Transfer</td><td>UPI</td><td>4,250</td><td>Completed</td></tr>
        <tr><td>7</td><td>07/03/2026</td><td>TXN007</td><td>Arun Kumar</td><td>EMP1...</td><td>Sales</td><td>Advance</td><td>UPI</td><td>5,600</td><td>Approved</td></tr>
        <tr><td>8</td><td>08/03/2026</td><td>TXN008</td><td>Priya S</td><td>EMP2...</td><td>Operations</td><td>Transfer</td><td>UPI</td><td>3,100</td><td>Completed</td></tr>
        <tr><td>9</td><td>09/03/2026</td><td>TXN009</td><td>Vignesh R</td><td>EMP3...</td><td>Collections</td><td>Reimbursement</td><td>NEFT</td><td>8,400</td><td>Completed</td></tr>
        <tr><td>10</td><td>10/03/2026</td><td>TXN010</td><td>Meena P</td><td>EMP4...</td><td>Sales</td><td>Transfer</td><td>UPI</td><td>2,750</td><td>Completed</td></tr>
        <tr><td>11</td><td>11/03/2026</td><td>TXN011</td><td>Ramesh K</td><td>EMP5...</td><td>Finance</td><td>Advance</td><td>IMPS</td><td>4,600</td><td>Approved</td></tr>
        <tr><td>12</td><td>12/03/2026</td><td>TXN012</td><td>Deepak M</td><td>EMP6...</td><td>Collections</td><td>Transfer</td><td>UPI</td><td>5,250</td><td>Completed</td></tr>
        <tr><td>13</td><td>13/03/2026</td><td>Arun Kumar</td><td>EMP1...</td><td>Sales</td><td>Reimbursement</td><td>NEFT</td><td>6,750</td><td>Completed</td></tr>
        <tr><td>14</td><td>14/03/2026</td><td>TXN014</td><td>Priya S</td><td>EMP2...</td><td>Operations</td><td>Transfer</td><td>UPI</td><td>3,950</td><td>Completed</td></tr>
        <tr><td>15</td><td>15/03/2026</td><td>TXN015</td><td>Vignesh R</td><td>EMP3...</td><td>Collections</td><td>Advance</td><td>IMPS</td><td>7,200</td><td>Pending</td></tr>
        <tr><td>16</td><td>16/03/2026</td><td>TXN016</td><td>Meena P</td><td>EMP4...</td><td>Sales</td><td>Transfer</td><td>UPI</td><td>4,300</td><td>Completed</td></tr>
        <tr><td>17</td><td>17/03/2026</td><td>TXN017</td><td>Ramesh K</td><td>EMP5...</td><td>Finance</td><td>Reimbursement</td><td>NEFT</td><td>5,900</td><td>Completed</td></tr>
        <tr><td>18</td><td>18/03/2026</td><td>TXN018</td><td>Deepak M</td><td>EMP6...</td><td>Collections</td><td>Transfer</td><td>UPI</td><td>6,450</td><td>Completed</td></tr>
        <tr><td>19</td><td>19/03/2026</td><td>TXN019</td><td>Arun Kumar</td><td>EMP1...</td><td>Sales</td><td>Advance</td><td>UPI</td><td>3,800</td><td>Approved</td></tr>
        <tr><td>20</td><td>20/03/2026</td><td>TXN020</td><td>Priya S</td><td>EMP2...</td><td>Operations</td><td>Transfer</td><td>UPI</td><td>8,100</td><td>Completed</td></tr>
        <tr><td>1</td><td>01/03/2026</td><td>TXN001</td><td>Arun Kumar</td><td>EMP1...</td><td>Sales</td><td>Transfer</td><td>UPI</td><td>2,500</td><td>Completed</td></tr>
        <tr><td>2</td><td>02/03/2026</td><td>TXN002</td><td>Priya S</td><td>EMP2...</td><td>Operations</td><td>Reimbursement</td><td>NEFT</td><td>4,800</td><td>Completed</td></tr>
        <tr><td>3</td><td>03/03/2026</td><td>TXN003</td><td>Vignesh R</td><td>EMP3...</td><td>Collections</td><td>Transfer</td><td>UPI</td><td>6,200</td><td>Completed</td></tr>
        <tr><td>4</td><td>04/03/2026</td><td>TXN004</td><td>Meena P</td><td>EMP4...</td><td>Sales</td><td>Advance</td><td>IMPS</td><td>3,500</td><td>Pending</td></tr>
        <tr><td>5</td><td>05/03/2026</td><td>TXN005</td><td>Ramesh K</td><td>EMP5...</td><td>Finance</td><td>Reimbursement</td><td>NEFT</td><td>7,850</td><td>Completed</td></tr>
        <tr><td>6</td><td>06/03/2026</td><td>TXN006</td><td>Deepak M</td><td>EMP6...</td><td>Collections</td><td>Transfer</td><td>UPI</td><td>4,250</td><td>Completed</td></tr>
        <tr><td>7</td><td>07/03/2026</td><td>TXN007</td><td>Arun Kumar</td><td>EMP1...</td><td>Sales</td><td>Advance</td><td>UPI</td><td>5,600</td><td>Approved</td></tr>
        <tr><td>8</td><td>08/03/2026</td><td>TXN008</td><td>Priya S</td><td>EMP2...</td><td>Operations</td><td>Transfer</td><td>UPI</td><td>3,100</td><td>Completed</td></tr>
        <tr><td>9</td><td>09/03/2026</td><td>TXN009</td><td>Vignesh R</td><td>EMP3...</td><td>Collections</td><td>Reimbursement</td><td>NEFT</td><td>8,400</td><td>Completed</td></tr>
        <tr><td>10</td><td>10/03/2026</td><td>TXN010</td><td>Meena P</td><td>EMP4...</td><td>Sales</td><td>Transfer</td><td>UPI</td><td>2,750</td><td>Completed</td></tr>
        <tr><td>11</td><td>11/03/2026</td><td>TXN011</td><td>Ramesh K</td><td>EMP5...</td><td>Finance</td><td>Advance</td><td>IMPS</td><td>4,600</td><td>Approved</td></tr>
        <tr><td>12</td><td>12/03/2026</td><td>TXN012</td><td>Deepak M</td><td>EMP6...</td><td>Collections</td><td>Transfer</td><td>UPI</td><td>5,250</td><td>Completed</td></tr>
        <tr><td>13</td><td>13/03/2026</td><td>Arun Kumar</td><td>EMP1...</td><td>Sales</td><td>Reimbursement</td><td>NEFT</td><td>6,750</td><td>Completed</td></tr>
        <tr><td>14</td><td>14/03/2026</td><td>TXN014</td><td>Priya S</td><td>EMP2...</td><td>Operations</td><td>Transfer</td><td>UPI</td><td>3,950</td><td>Completed</td></tr>
        <tr><td>15</td><td>15/03/2026</td><td>TXN015</td><td>Vignesh R</td><td>EMP3...</td><td>Collections</td><td>Advance</td><td>IMPS</td><td>7,200</td><td>Pending</td></tr>
        <tr><td>16</td><td>16/03/2026</td><td>TXN016</td><td>Meena P</td><td>EMP4...</td><td>Sales</td><td>Transfer</td><td>UPI</td><td>4,300</td><td>Completed</td></tr>
        <tr><td>17</td><td>17/03/2026</td><td>TXN017</td><td>Ramesh K</td><td>EMP5...</td><td>Finance</td><td>Reimbursement</td><td>NEFT</td><td>5,900</td><td>Completed</td></tr>
        <tr><td>18</td><td>18/03/2026</td><td>TXN018</td><td>Deepak M</td><td>EMP6...</td><td>Collections</td><td>Transfer</td><td>UPI</td><td>6,450</td><td>Completed</td></tr>
        <tr><td>19</td><td>19/03/2026</td><td>TXN019</td><td>Arun Kumar</td><td>EMP1...</td><td>Sales</td><td>Advance</td><td>UPI</td><td>3,800</td><td>Approved</td></tr>
        <tr><td>20</td><td>20/03/2026</td><td>TXN020</td><td>Priya S</td><td>EMP2...</td><td>Operations</td><td>Transfer</td><td>UPI</td><td>8,100</td><td>Completed</td></tr>
        <tr><td colspan="8"><strong>Grand Total</strong></td><td><strong>1,05,850</strong></td><td><strong>—</strong></td></tr>
    </tbody>
</table>
'''
}


BOILERPLATE = [
    "The acts committed by you are not only in gross violation of Company policies but also grave and serious in nature, highly prejudicial to the interest of the Company, also tantamount to misconduct and warrants severe punishment including termination of your services from the Company, if proved.",
    "Therefore, you are hereby called upon to immediately remit the misappropriated amount and to give your explanation within 3 days from receipt of this, as to why an appropriate disciplinary action including dismissal from the services should not be taken against you.",
    "Your explanation should reach us within the period stipulated above, failing which it would be presumed that you have no valid explanation to offer in that eventuality, appropriate action would follow without any further reference to you in this behalf."
]

R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"

def _parse_html_table_to_grid(html_table: str):
    soup = BeautifulSoup(html_table, "html.parser")
    table = soup.find("table")
    if table is None:
        raise ValueError("No <table> found in the given HTML.")

    rows = table.find_all("tr", recursive=True)
    pending = {}
    grid = []
    num_cols = 0

    for r_idx, tr in enumerate(rows):
        grid.append({})
        c_idx = 0
        cells = tr.find_all(["td", "th"], recursive=False)
        cell_iter = iter(cells)
        current_cell = next(cell_iter, None)

        while current_cell is not None or c_idx in pending:
            if c_idx in pending:
                remaining, cell_dict = pending[c_idx]
                grid[r_idx][c_idx] = cell_dict
                if remaining - 1 > 0:
                    pending[c_idx] = (remaining - 1, cell_dict)
                else:
                    del pending[c_idx]
                c_idx += 1
                continue

            if current_cell is None:
                break

            rowspan = int(current_cell.get("rowspan", 1) or 1)
            colspan = int(current_cell.get("colspan", 1) or 1)
            text = current_cell.get_text(separator="\n", strip=True)
            is_header = current_cell.name == "th"

            cell_dict = {
                "text": text, "is_origin": True,
                "r0": r_idx, "c0": c_idx,
                "r1": r_idx + rowspan - 1, "c1": c_idx + colspan - 1,
                "header": is_header,
            }
            for cc in range(c_idx, c_idx + colspan):
                grid[r_idx][cc] = cell_dict
                if rowspan > 1:
                    pending[cc] = (rowspan - 1, cell_dict)

            c_idx += colspan
            current_cell = next(cell_iter, None)

        num_cols = max(num_cols, c_idx)

    num_rows = len(grid)
    for r in range(num_rows):
        for c in range(num_cols):
            if c not in grid[r]:
                grid[r][c] = {"text": "", "is_origin": True,
                              "r0": r, "c0": c, "r1": r, "c1": c, "header": False}

    return grid, num_rows, num_cols


def extract_html_tables(combined_html: str):
    soup = BeautifulSoup(combined_html, "html.parser")
    return [str(t) for t in soup.find_all("table")]

def collapse_placeholder_paragraph(paragraph):
    for run in paragraph.runs:
        run_element = run._element

        for child in list(run_element):
            if child.tag in {
                qn("w:t"),
                qn("w:tab"),
                qn("w:br"),
                qn("w:cr"),
            }:
                run_element.remove(child)

    paragraph.paragraph_format.space_before = Pt(0)
    paragraph.paragraph_format.space_after = Pt(0)
    paragraph.paragraph_format.line_spacing_rule = WD_LINE_SPACING.EXACTLY
    paragraph.paragraph_format.line_spacing = Pt(1)

    for run in paragraph.runs:
        run.font.size = Pt(1)

def clean_md(s):
    return re.sub(r'\*\*(.*?)\*\*', r'\1', s).strip()

LINE_SHAPE_PATH_RE = re.compile(r"^m,l\d+,e$")

def remove_zero_height_line_shapes(paragraph):
    for element in list(paragraph._element.iter()):
        if element.tag.split("}")[-1] != "shape":
            continue

        path = (element.get("path") or "").strip()

        if LINE_SHAPE_PATH_RE.match(path):
            parent = element.getparent()

            if parent is not None:
                parent.remove(element)

def remove_unwanted_lines(paragraph):
    paragraph_element = paragraph._element

    for element in list(paragraph_element.iter()):
        local_name = element.tag.split("}")[-1]

        if local_name == "line":
            parent = element.getparent()

            if parent is not None:
                parent.remove(element)

    remove_zero_height_line_shapes(paragraph)

    paragraph_properties = paragraph._p.get_or_add_pPr()
    paragraph_borders = paragraph_properties.find(qn("w:pBdr"))

    if paragraph_borders is not None:
        paragraph_properties.remove(paragraph_borders)

def parse_markdown_tables(text):
    lines = [x.rstrip() for x in text.strip().splitlines()]
    tables, i = [], 0
    while i < len(lines):
        if lines[i].strip().startswith('|') and i + 1 < len(lines) and re.match(r'^\s*\|?[\s:\-|]+\|?\s*$', lines[i+1]):
            header = [clean_md(c) for c in lines[i].strip().strip('|').split('|')]
            rows, i = [], i + 2
            while i < len(lines) and lines[i].strip().startswith('|'):
                if i + 1 < len(lines) and re.match(r'^\s*\|?[\s:\-|]+\|?\s*$', lines[i+1]):
                    break
                rows.append([clean_md(c) for c in lines[i].strip().strip('|').split('|')])
                i += 1
            tables.append((header, rows))
        else:
            i += 1
    return tables

def set_cell_margins(cell, top=40, start=40, bottom=40, end=40):
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = tcPr.first_child_found_in('w:tcMar')
    if tcMar is None:
        tcMar = OxmlElement('w:tcMar'); tcPr.append(tcMar)
    for m, v in [('top',top),('start',start),('bottom',bottom),('end',end)]:
        node = tcMar.find(qn('w:'+m))
        if node is None: node = OxmlElement('w:'+m); tcMar.append(node)
        node.set(qn('w:w'), str(v)); node.set(qn('w:type'), 'dxa')

def add_run(p, text, bold=False, size=11, underline=False):
    r = p.add_run(text)
    r.bold = bold
    r.underline = underline
    r.font.name = 'Calibri'
    r.font.size = Pt(size)
    return r

def add_p_before(anchor, text='', align=None, after=0, before=0, line=1.0, bold=False, size=11, underline=False):
    pxml = OxmlElement('w:p')
    anchor._p.addprevious(pxml)
    from docx.text.paragraph import Paragraph
    p = Paragraph(pxml, anchor._parent)
    if align is not None:
        p.alignment = align
    p.paragraph_format.space_after = Pt(after)
    p.paragraph_format.space_before = Pt(before)
    p.paragraph_format.line_spacing = line
    p.paragraph_format.left_indent = Pt(0)
    p.paragraph_format.right_indent = Pt(0)
    p.paragraph_format.first_line_indent = Pt(0)
    add_run(p, text, bold, size, underline)
    return p

def add_html_table_before(doc, anchor, html_table_str):
    grid, num_rows, num_cols = _parse_html_table_to_grid(html_table_str)
    if num_rows == 0 or num_cols == 0:
        return None

    table = doc.add_table(rows=num_rows, cols=num_cols)

    table.autofit = False
    table.alignment = WD_TABLE_ALIGNMENT.CENTER

    tbl_pr = table._tbl.tblPr

    section = doc.sections[0]
    usable_in = (
        section.page_width.inches
        - section.left_margin.inches
        - section.right_margin.inches
    )
    total_twips = int(usable_in * 1440)

    # Calculate Weights and Dynamic Min-Widths based on Word Length
    col_max_len = [4] * num_cols
    col_min_twips = [600] * num_cols

    for r in range(num_rows):
        for c in range(num_cols):
            text = grid[r][c]["text"]
            length = len(text)
            if length > col_max_len[c]:
                col_max_len[c] = length
            
            # Predict the width required for the longest single word to avoid ugly line breaks
            for word in text.split():
                # 85 twips per character safely covers size 8 font, + 100 for cell margins
                word_width = len(word) * 85 + 100
                if word_width > col_min_twips[c]:
                    col_min_twips[c] = word_width

    # Hard cap the minimum width limit so a single abnormal string doesn't break the layout
    max_allowed_min = max(600, total_twips // max(1, num_cols))
    col_min_twips = [min(w, max_allowed_min) for w in col_min_twips]

    col_widths = [0] * num_cols
    unassigned_cols = list(range(num_cols))
    available_twips = total_twips

    # Water-filling algorithm
    while unassigned_cols:
        current_weight = sum(col_max_len[i] for i in unassigned_cols)
        
        if current_weight == 0:
            per_col = available_twips // len(unassigned_cols)
            for i in unassigned_cols:
                col_widths[i] = per_col
            col_widths[unassigned_cols[-1]] += available_twips % len(unassigned_cols)
            break

        violators = []
        for i in unassigned_cols:
            w = round(available_twips * col_max_len[i] / current_weight)
            if w < col_min_twips[i]:
                violators.append(i)

        if violators:
            for i in violators:
                col_widths[i] = col_min_twips[i]
                available_twips -= col_min_twips[i]
                unassigned_cols.remove(i)
        else:
            for i in unassigned_cols[:-1]:
                w = round(available_twips * col_max_len[i] / current_weight)
                col_widths[i] = w
                available_twips -= w
                current_weight -= col_max_len[i]
                
            col_widths[unassigned_cols[-1]] = available_twips
            break

    # Fix table width mapping - Force Word/LO to span exactly 100% of the margins
    tbl_w = tbl_pr.find(qn("w:tblW"))
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:w"), "5000") # 5000 is 100% width in docx specification
    tbl_w.set(qn("w:type"), "pct")

    # Center alignment
    jc = tbl_pr.find(qn("w:jc"))
    if jc is None:
        jc = OxmlElement("w:jc")
        tbl_pr.append(jc)
    jc.set(qn("w:val"), "center")

    # Force overall indent to 0
    tbl_ind = tbl_pr.find(qn("w:tblInd"))
    if tbl_ind is None:
        tbl_ind = OxmlElement("w:tblInd")
        tbl_pr.append(tbl_ind)
    tbl_ind.set(qn("w:w"), "0")
    tbl_ind.set(qn("w:type"), "dxa")

    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        border = OxmlElement(f"w:{edge}")
        border.set(qn("w:val"), "single")
        border.set(qn("w:sz"), "4") # Thin elegant border
        border.set(qn("w:space"), "0")
        border.set(qn("w:color"), "A0A0A0") # Lighter grey to reduce visual clutter
        borders.append(border)
    tbl_pr.append(borders)

    tbl_layout = tbl_pr.find(qn("w:tblLayout"))
    if tbl_layout is None:
        tbl_layout = OxmlElement("w:tblLayout")
        tbl_pr.append(tbl_layout)
    tbl_layout.set(qn("w:type"), "fixed")

    # Apply the computed widths to the table grid.
    tbl_grid = table._tbl.find(qn("w:tblGrid"))
    if tbl_grid is not None:
        for gc, width in zip(tbl_grid.findall(qn("w:gridCol")), col_widths):
            gc.set(qn("w:w"), str(width))

    # Apply bounds per cell level
    for row in table.rows:
        for c, cell in enumerate(row.cells):
            tcPr = cell._tc.get_or_add_tcPr()
            tcW = tcPr.find(qn("w:tcW"))
            if tcW is None:
                tcW = OxmlElement("w:tcW")
                tcPr.append(tcW)
            tcW.set(qn("w:w"), str(col_widths[c]))
            tcW.set(qn("w:type"), "dxa")

    written = set()
    for r in range(num_rows):
        for c in range(num_cols):
            info = grid[r][c]
            key = (info["r0"], info["c0"])
            if key in written:
                continue
            written.add(key)

            cell = table.cell(info["r0"], info["c0"])
            cell.text = ""
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.left_indent = 0
            p.paragraph_format.right_indent = 0
            p.paragraph_format.first_line_indent = 0
            
            # Using Font size 8 for better legibility without overlapping strings 
            add_run(p, info["text"], bold=info["header"], size=8)
            set_cell_margins(cell)

    merged_already = set()
    for r in range(num_rows):
        for c in range(num_cols):
            info = grid[r][c]
            span_key = (info["r0"], info["c0"], info["r1"], info["c1"])
            if span_key in merged_already:
                continue
            merged_already.add(span_key)
            if info["r1"] > info["r0"] or info["c1"] > info["c0"]:
                table.cell(info["r0"], info["c0"]).merge(
                    table.cell(info["r1"], info["c1"])
                )

    anchor._p.addprevious(table._tbl)
    return table

def paragraph_has_page_spanning_shape(paragraph, height_threshold=50000):
    for element in paragraph._element.iter():
        if element.tag.split("}")[-1] != "shape":
            continue

        style = element.get("style", "")
        match = re.search(r"height:(\d+)", style)

        if match and int(match.group(1)) >= height_threshold:
            return True

    return False

def add_centered_heading_table(doc, anchor, text, size=12, bold=True, underline=True, before=50, after=12):
    table = doc.add_table(rows=1, cols=1)
    table.autofit = True
    table.alignment = WD_TABLE_ALIGNMENT.CENTER

    tbl_pr = table._tbl.tblPr

    tbl_w = tbl_pr.find(qn("w:tblW"))
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:w"), "0")
    tbl_w.set(qn("w:type"), "auto")

    jc = tbl_pr.find(qn("w:jc"))
    if jc is None:
        jc = OxmlElement("w:jc")
        tbl_pr.append(jc)
    jc.set(qn("w:val"), "center")

    tbl_ind = tbl_pr.find(qn("w:tblInd"))
    if tbl_ind is None:
        tbl_ind = OxmlElement("w:tblInd")
        tbl_pr.append(tbl_ind)
    tbl_ind.set(qn("w:w"), "0")
    tbl_ind.set(qn("w:type"), "dxa")

    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        border = OxmlElement(f"w:{edge}")
        border.set(qn("w:val"), "nil")
        border.set(qn("w:sz"), "0")
        border.set(qn("w:space"), "0")
        border.set(qn("w:color"), "auto")
        borders.append(border)
    tbl_pr.append(borders)

    tbl_layout = tbl_pr.find(qn("w:tblLayout"))
    if tbl_layout is None:
        tbl_layout = OxmlElement("w:tblLayout")
        tbl_pr.append(tbl_layout)
    tbl_layout.set(qn("w:type"), "autofit")

    tbl_grid = table._tbl.find(qn("w:tblGrid"))
    if tbl_grid is not None:
        gc = tbl_grid.find(qn("w:gridCol"))
        if gc is not None:
            gc.set(qn("w:w"), "0")

    cell = table.cell(0, 0)
    tcPr = cell._tc.get_or_add_tcPr()
    tcW = tcPr.find(qn("w:tcW"))
    if tcW is None:
        tcW = OxmlElement("w:tcW")
        tcPr.append(tcW)
    tcW.set(qn("w:w"), "0")
    tcW.set(qn("w:type"), "auto")

    cell.text = ""
    p = cell.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(before)
    p.paragraph_format.space_after = Pt(after)
    add_run(p, text, bold=bold, size=size, underline=underline)

    anchor._p.addprevious(table._tbl)
    return table

def paragraph_has_graphics(paragraph):
    graphic_local_names = {
        "drawing",
        "pict",
        "object",
        "shape",
        "rect",
        "line",
        "textbox",
        "group",
        "imagedata",
    }

    for element in paragraph._element.iter():
        local_name = element.tag.split("}")[-1]

        if local_name in graphic_local_names:
            return True

    return False

def set_footer_text(section):
    footer = section.footer
    clear_footer(footer)

    footer.is_linked_to_previous = False
    section.footer_distance = Inches(0.22)

    footer_lines = [
        (
            "Corp. Office: ",
            "No. 29, Jayalakshmi Estates, Third Floor, Haddows Road, "
            "Nungambakkam, Chennai - 600 006. Phone: 044-2828 6500 "
            "Fax: 044-2828 6570",
        ),
        (
            "Regd. Office: ",
            "TVR Pride, No. 383,16th Main, 3rd Block, Koramangala, "
            "Bengaluru, Karnataka-560034. Phone: 8098145257",
        ),
        (
            "Customer Correspondence Address: ",
            "Bristol Towers, 2nd Floor, No.10, South Phase, "
            "Thiru-Vi-Ka Industrial Estate, Guindy, Chennai-600 032.",
        ),
    ]

    first_paragraph = footer.paragraphs[0]

    for index, (label, value) in enumerate(footer_lines):
        if index == 0:
            paragraph = first_paragraph
        else:
            paragraph = footer.add_paragraph()

        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        paragraph.paragraph_format.space_before = Pt(0)
        paragraph.paragraph_format.space_after = Pt(0)
        paragraph.paragraph_format.line_spacing = 1.0

        label_run = paragraph.add_run(label)
        label_run.bold = True
        label_run.font.name = "Calibri"
        label_run.font.size = Pt(6.5)
        label_run.font.color.rgb = RGBColor(0x1F, 0x4E, 0x79)

        value_run = paragraph.add_run(value)
        value_run.font.name = "Calibri"
        value_run.font.size = Pt(6.5)
        value_run.font.color.rgb = RGBColor(0x1F, 0x4E, 0x79)

    final_paragraph = footer.add_paragraph()
    final_paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    final_paragraph.paragraph_format.space_before = Pt(0)
    final_paragraph.paragraph_format.space_after = Pt(0)
    final_paragraph.paragraph_format.line_spacing = 1.0

    footer_items = [
        ("Website: ", "www.tvscredit.com"),
        ("   Customer care number: ", "044-66123456"),
        ("   CIN: ", "U65920KA2008PLC218369"),
    ]

    for label, value in footer_items:
        label_run = final_paragraph.add_run(label)
        label_run.bold = True
        label_run.font.name = "Calibri"
        label_run.font.size = Pt(6.5)
        label_run.font.color.rgb = RGBColor(0x1F, 0x4E, 0x79)

        value_run = final_paragraph.add_run(value)
        value_run.font.name = "Calibri"
        value_run.font.size = Pt(6.5)
        value_run.font.color.rgb = RGBColor(0x1F, 0x4E, 0x79)

def clear_footer(footer):
    footer_element = footer._element

    for child in list(footer_element):
        footer_element.remove(child)

    footer_element.append(OxmlElement("w:p"))


def find_soffice():
    candidates = [
        shutil.which("soffice"),
        shutil.which("libreoffice"),
        r"C:\Program Files\LibreOffice\program\soffice.exe",
        r"C:\Program Files (x86)\LibreOffice\program\soffice.exe",
    ]

    for path in candidates:
        if path and Path(path).exists():
            return path

    raise FileNotFoundError(
        "LibreOffice was not found. Install LibreOffice or add "
        "soffice.exe to the system PATH."
    )


def convert_docx_to_pdf(docx_path, timeout=60):
    docx_path = Path(docx_path)
    out_dir = docx_path.parent
    produced_pdf = out_dir / (docx_path.stem + ".pdf")

    soffice = find_soffice()

    with tempfile.TemporaryDirectory() as profile_dir:
        cmd = [
            soffice,
            "--headless",
            "--norestore",
            "--convert-to", "pdf",
            "--outdir", str(out_dir),
            f"-env:UserInstallation={Path(profile_dir).resolve().as_uri()}",
            str(docx_path),
        ]

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout,
            )
        except subprocess.TimeoutExpired as e:
            raise RuntimeError(
                f"LibreOffice conversion timed out after {timeout}s "
                f"for {docx_path.name}"
            ) from e

        if result.returncode != 0:
            raise RuntimeError(
                f"LibreOffice conversion failed (exit {result.returncode}):\n"
                f"stdout: {result.stdout}\n"
                f"stderr: {result.stderr}"
            )

    if not produced_pdf.exists():
        raise RuntimeError(
            f"Expected PDF not found after conversion: {produced_pdf}\n"
            f"soffice stdout: {result.stdout}\n"
            f"soffice stderr: {result.stderr}"
        )

    return produced_pdf

def clear_text_preserve_graphics(paragraph):
    remove_unwanted_lines(paragraph)
    remove_table_style_bottom_border(paragraph)

    removable_tags = {
        qn("w:t"),
        qn("w:tab"),
        qn("w:br"),
        qn("w:cr"),
        qn("w:noBreakHyphen"),
        qn("w:softHyphen"),
    }

    protected_local_names = {
        "drawing",
        "pict",
        "object",
        "shape",
        "rect",
        "textbox",
        "group",
        "imagedata",
    }

    def is_inside_graphic(element):
        parent = element.getparent()

        while parent is not None:
            local_name = parent.tag.split("}")[-1]

            if local_name in protected_local_names:
                return True

            parent = parent.getparent()

        return False

    for run in paragraph.runs:
        run.font.size = Pt(1)

    if paragraph_has_page_spanning_shape(paragraph):
        return

    paragraph_format = paragraph.paragraph_format
    paragraph_format.space_before = Pt(0)
    paragraph_format.space_after = Pt(0)
    paragraph_format.line_spacing_rule = WD_LINE_SPACING.EXACTLY
    paragraph_format.line_spacing = Pt(1)
    paragraph_format.keep_together = False
    paragraph_format.keep_with_next = False
    paragraph_format.page_break_before = False

    paragraph_properties = paragraph._p.get_or_add_pPr()

    for tag_name in (
        "w:pageBreakBefore",
        "w:keepNext",
        "w:keepLines",
        "w:contextualSpacing",
        "w:widowControl",
        "w:pBdr",
    ):
        node = paragraph_properties.find(qn(tag_name))

        if node is not None:
            paragraph_properties.remove(node)

def remove_table_style_bottom_border(paragraph):
    for run in paragraph.runs:
        run_properties = run._element.find(qn("w:rPr"))
        if run_properties is None:
            continue
        run_border = run_properties.find(qn("w:bdr"))
        if run_border is not None:
            run_properties.remove(run_border)

def find_and_remove_rule_tables(doc, before_element):
    body = doc.element.body

    def table_has_graphics(table_element):
        graphic_local_names = {
            "drawing", "pict", "object", "shape",
            "rect", "imagedata", "textbox", "group",
        }
        for element in table_element.iter():
            if element.tag.split("}")[-1] in graphic_local_names:
                return True
        return False

    def table_has_visible_text(table_element):
        for t in table_element.iter(qn("w:t")):
            if t.text and t.text.strip():
                return True
        return False

    preceding = before_element.xpath("preceding::*")

    for tbl in list(body.findall(qn("w:tbl"))):
        if tbl not in preceding:
            continue
        if table_has_graphics(tbl):
            continue
        if table_has_visible_text(tbl):
            continue
        parent = tbl.getparent()
        if parent is not None:
            parent.remove(tbl)

def _clone_element_with_relationships(source_part, target_part, element):
    """Deep-copy an XML element, remapping every relationship-id attribute
    from the source part's relationships to newly-created relationships on 
    the target part (fixing broken images/links when moving elements to the header).
    """
    new_element = deepcopy(element)
    remapped = {}

    for el in new_element.iter():
        for attr_name in list(el.attrib):
            if not attr_name.startswith("{" + R_NS + "}"):
                continue

            old_rid = el.attrib[attr_name]
            if not old_rid:
                continue

            if old_rid not in remapped:
                if old_rid not in source_part.rels:
                    continue

                rel = source_part.rels[old_rid]
                if rel.is_external:
                    new_rid = target_part.relate_to(
                        rel.target_ref, rel.reltype, is_external=True
                    )
                else:
                    new_rid = target_part.relate_to(
                        rel.target_part, rel.reltype
                    )
                remapped[old_rid] = new_rid

            el.attrib[attr_name] = remapped[old_rid]

    return new_element

def move_letterhead_to_header(doc, graphic_paragraphs):
    """Relocate the letterhead artwork (logos, green side bar, footer
    bar) from the document body into the section header so it repeats 
    perfectly on multi-page overflows.
    """
    section = doc.sections[0]
    header = section.header
    header.is_linked_to_previous = False
    section.different_first_page_header_footer = False

    header_element = header._element
    for existing_paragraph in header_element.findall(qn("w:p")):
        header_element.remove(existing_paragraph)

    for paragraph in graphic_paragraphs:
        new_paragraph_element = _clone_element_with_relationships(
            doc.part, header.part, paragraph._element
        )
        header_element.append(new_paragraph_element)

    for paragraph in graphic_paragraphs:
        element = paragraph._element
        parent = element.getparent()
        if parent is not None:
            parent.remove(element)

def prepare_template_placeholders(doc):
    from docx.text.paragraph import Paragraph

    graphic_paragraphs = [
        paragraph
        for paragraph in list(doc.paragraphs)
        if paragraph_has_graphics(paragraph)
    ]

    # Pre-clean paragraphs to clear invisible strings/margins before transferring to header
    for paragraph in graphic_paragraphs:
        clear_text_preserve_graphics(paragraph)

    move_letterhead_to_header(doc, graphic_paragraphs)

    for paragraph in list(doc.paragraphs):
        paragraph_element = paragraph._element
        parent = paragraph_element.getparent()

        if parent is not None:
            parent.remove(paragraph_element)

    body = doc.element.body
    anchor_xml = OxmlElement("w:p")
    sect_pr = body.find(qn("w:sectPr"))

    if sect_pr is not None:
        sect_pr.addprevious(anchor_xml)
    else:
        body.append(anchor_xml)

    insertion_anchor = Paragraph(anchor_xml, doc._body)

    insertion_anchor.paragraph_format.space_before = Pt(0)
    insertion_anchor.paragraph_format.space_after = Pt(0)
    insertion_anchor.paragraph_format.line_spacing_rule = (
        WD_LINE_SPACING.EXACTLY
    )
    insertion_anchor.paragraph_format.line_spacing = Pt(1)

    return insertion_anchor 

def to_roman(num):
    val = [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1]
    syb = ["M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"]
    roman_num = ''
    i = 0
    while num > 0:
        for _ in range(num // val[i]):
            roman_num += syb[i]
            num -= val[i]
        i += 1
    return roman_num


def generate(response, template, out_docx, out_pdf, out_txt):
    shutil.copyfile(template, out_docx)

    doc = Document(out_docx)

    section = doc.sections[0]
    
    # FIXED: Increased top_margin from 0.72 to 1.4 inches. 
    # This acts as a bumper for overflowing tables, forcing them to start underneath the logo on continuation pages.
    section.top_margin = Inches(1.4) 
    section.bottom_margin = Inches(0.78)
    section.left_margin = Inches(0.8)
    section.right_margin = Inches(0.8)
    section.footer_distance = Inches(0.2)

    normal = doc.styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(11)

    anchor = prepare_template_placeholders(doc)

    add_p_before(
        anchor,
        response["generation_date"],
        WD_ALIGN_PARAGRAPH.RIGHT,
        after=8,
        before=0, # FIXED: Reduced this from 20 to 0 so the date doesn't get pushed down too far on page 1
        line=1.15,
        size=11,
    )

    add_p_before(anchor, '', after=6)

    for line in response["address_to"].splitlines():
        add_p_before(
            anchor,
            line.strip(),
            after=0,
            before=0,
            line=1.15,
            size=11,
        )

    add_p_before(anchor, '', after=8)
    add_p_before(anchor, response['employee_name'] + ',', after=12, line=1.15, size=11)
    
    p = add_p_before(anchor, after=4, line=1.15)
    add_run(p, 'Sub: ', True)
    add_run(p, response['subject'], False)
    
    p = add_p_before(anchor, after=10, line=1.15)
    add_run(p, 'Ref: ', True)
    add_run(p, response['Ref'], False)
    
    content = ' '.join(x.strip() for x in response['actual_content'].splitlines())
    add_p_before(anchor, content, WD_ALIGN_PARAGRAPH.JUSTIFY, after=12, line=1.15, size=11)
    
    for text in BOILERPLATE: 
        add_p_before(anchor, text, WD_ALIGN_PARAGRAPH.JUSTIFY, after=12, line=1.15, size=11)
        
    add_p_before(anchor, 'For TVS Credit Services Ltd.', after=30, bold=True, line=1.15, size=11)
    add_p_before(anchor, 'Authorized Signatory', after=0, bold=True, line=1.15, size=11)

    html_tables = extract_html_tables(response["table_annexure"])
    
    for i, html_table_str in enumerate(html_tables):
        p = add_p_before(anchor, "")
        p.paragraph_format.page_break_before = True

        if len(html_tables) > 1:
            heading_text = f"ANNEXURE {to_roman(i + 1)}"
        else:
            heading_text = "ANNEXURE"

        add_p_before(
            anchor,
            heading_text,
            WD_ALIGN_PARAGRAPH.CENTER,
            after=12,
            before=20,
            line=1.15,
            bold=True,
            size=12,
            underline=True,
        )

        add_html_table_before(doc, anchor, html_table_str)
        add_p_before(anchor, "", after=6)

    doc.save(out_docx)
    produced = convert_docx_to_pdf(out_docx)
    
    if produced != Path(out_pdf): 
        shutil.move(produced, out_pdf)
    
    lines = [
        response['generation_date'], '', 
        response['address_to'], '', 
        response['employee_name'] + ',', '',
        'Sub: ' + response['subject'], 
        'Ref: ' + response['Ref'], '', 
        content, ''
    ] + BOILERPLATE + [
        '', 
        'For TVS Credit Services Ltd.', 
        'Authorized Signatory', 
        ''
    ]
           
    if len(html_tables) > 1:
        for i, table_str in enumerate(html_tables):
            lines.extend(['', f'ANNEXURE {to_roman(i + 1)}', table_str.strip()])
    else:
        lines.extend(['', 'ANNEXURE', response['table_annexure'].strip()])
        
    Path(out_txt).write_text('\n'.join(lines), encoding='utf-8')
    
    
if __name__ == '__main__':
    base = Path(r'X:\TVS-Intern\HR_\test')
    generate(
        RESPONSE,
        str(r"C:\Users\Dell\Downloads\tvstemplate_.docx"), 
        base / 'SCN__Employee.docx',
        base / 'SCN__Employee.pdf',
        base / 'SCN__Employee.txt'
    )
    print('Generated DOCX, PDF, and TXT.')